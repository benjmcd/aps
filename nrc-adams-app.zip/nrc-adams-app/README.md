# NRC ADAMS Query Application

Local-first application for querying and storing documents from the NRC ADAMS Public Search (APS) API.

## Project Status: Milestone 1 ✓

**Implemented:**
- ✅ Database schema with SQLAlchemy + Alembic migrations
- ✅ Query creation and execution against NRC APS API
- ✅ Query run persistence with document metadata
- ✅ Frontend: Query Builder with dynamic filter builder
- ✅ Frontend: Results display with selection
- ✅ Tests: Payload canonicalization and query route tests with mocked APS responses

**Coming Next:**
- 📋 Milestone 2: Document ingestion and file storage
- 📋 Milestone 3: Text partitioning and storage
- 📋 Milestone 4: Error handling, retry logic, and manual review queue

## Architecture

### Backend
- **FastAPI** web framework
- **SQLAlchemy 2.x** with Alembic migrations
- **SQLite** database (configurable to PostgreSQL)
- **httpx** for NRC APS API communication
- **pytest** with mocked HTTP for testing

### Frontend
- **Vite + React + TypeScript**
- **TanStack Query** for API state management
- Hash-based routing (no external router library)
- Minimal UI with inline styles

### Data Flow
1. User builds query in QueryBuilder → saves to database
2. User runs query → backend calls NRC APS API → persists results
3. Results displayed in table → user selects documents
4. (Milestone 2+) Selected documents ingested → PDFs downloaded → text extracted → stored locally

## Quick Start

### Prerequisites
- Python 3.12+
- Node.js 18+
- NRC APS API Subscription Key (set in `.env`)

### Installation

```bash
# Clone repository
git clone <repo-url>
cd nrc-adams-app

# Install dependencies
make install

# Configure environment
cp .env.example .env
# Edit .env and add your APS_SUBSCRIPTION_KEY

# Run database migrations
make migrate
```

### Development

```bash
# Terminal 1: Start backend (port 8000)
make backend-dev

# Terminal 2: Start frontend (port 5173)
make frontend-dev
```

Open http://localhost:5173 in your browser.

### Testing

```bash
# Run backend tests
make test
```

All tests use mocked HTTP responses - no live NRC connectivity required.

## Environment Variables

See `.env.example` for all configuration options:

- `APS_SUBSCRIPTION_KEY` - NRC APS API key (required for production)
- `DATABASE_URL` - Database connection (default: `sqlite:///./data/app.db`)
- `BLOB_ROOT` - PDF storage directory (default: `./data/blobs`)
- `CORS_ORIGINS` - Allowed frontend origins (default: `http://localhost:5173`)

## Database Schema

### Queries Table
Stores saved query definitions with canonical APS payload JSON.

### Query Runs Table
Records of query executions with status and response metadata.

### Documents Table
Document metadata (title, date, URL) and file storage info (sha256, path).

### Query Run Documents Table
Junction table linking runs to documents with disposition (`seen`, `ingested`, `skipped`, `error`).

### Document Text Table
Partitioned text chunks from APS indexed content and PDF extraction (Milestone 3).

### Jobs Table
Background job queue for ingestion with retry logic (Milestone 2+).

See `backend/alembic/versions/0001_init.py` for complete schema definition.

## API Endpoints

### Milestone 1 (Current)
- `POST /api/queries` - Create saved query
- `POST /api/queries/{id}/run?skip=N` - Execute query with pagination

### Milestone 2+ (Coming)
- `POST /api/query-runs/{id}/ingest` - Ingest selected documents
- `GET /api/library/tree` - Get hierarchical document tree
- `GET /api/documents/{accession}/download` - Download PDF
- `GET /api/jobs` - List jobs with status filter
- `POST /api/jobs/{id}/retry` - Retry failed job

## Project Structure

```
nrc-adams-app/
├── backend/              # FastAPI backend
│   ├── app/
│   │   ├── api/          # Route handlers
│   │   ├── services/     # Business logic
│   │   ├── tests/        # Test suite with fixtures
│   │   ├── config.py     # Environment configuration
│   │   ├── db.py         # Database setup
│   │   ├── models.py     # SQLAlchemy models
│   │   ├── schemas.py    # Pydantic models
│   │   └── main.py       # FastAPI app
│   ├── alembic/          # Database migrations
│   └── pyproject.toml    # Python dependencies
├── frontend/             # React frontend
│   ├── src/
│   │   ├── pages/        # Page components
│   │   ├── components/   # Reusable components
│   │   ├── api.ts        # API client
│   │   └── types.ts      # TypeScript types
│   └── package.json      # Node dependencies
├── data/                 # Runtime data (gitignored)
│   ├── app.db            # SQLite database
│   └── blobs/            # PDF file storage
├── .env                  # Environment config (gitignored)
├── .env.example          # Example config
├── Makefile              # Development commands
└── README.md             # This file
```

## Development Workflow

### Creating a Query
1. Navigate to Query Builder
2. Set query name and search parameters
3. Add filters (field/operator/value)
4. Click "Save Query"
5. Click "Run Query" to execute against APS

### Viewing Results
1. Results automatically displayed after running query
2. Select documents with checkboxes
3. (Milestone 2+) Click "Ingest Selected" to download and store

### Running Tests
```bash
cd backend
pytest -v
```

Tests include:
- Payload canonicalization stability
- Query creation and execution
- Document upsert idempotency
- Mocked APS API responses

## NRC APS API Details

The application integrates with the NRC ADAMS Public Search API:

**Base URL:** `https://adams-api.nrc.gov/aps/api`

**Required Header:** `Ocp-Apim-Subscription-Key: <your-key>`

**Endpoints Used:**
- `POST /search` - Search document library
- `GET /search/{accessionNumber}` - Get document metadata + indexed content

See spec document for complete API contract details.

## Troubleshooting

### Backend won't start
- Check Python version: `python --version` (should be 3.12+)
- Verify dependencies: `cd backend && pip install -e ".[dev]"`
- Check database: `make migrate`

### Frontend won't start
- Check Node version: `node --version` (should be 18+)
- Verify dependencies: `cd frontend && npm install`
- Check backend is running on port 8000

### Tests failing
- Ensure test database is clean: `cd backend && pytest --cache-clear`
- Check respx is installed: `pip install respx`
- Tests should NOT require live NRC connectivity

### API errors
- Verify `APS_SUBSCRIPTION_KEY` is set in `.env`
- Check CORS settings if calling from different origin
- Inspect backend logs for detailed error messages

## Contributing

This project follows a strict specification - see the spec document for:
- Absolute constraints (DO NOT VIOLATE)
- Tech stack (FORCED)
- Database schema (FORCED)
- Repo structure (FORCED)
- API contracts (FORCED)

Each milestone is implemented as a separate PR with tests passing before proceeding.

## License

[Your license here]

# NRC ADAMS Query Frontend

React + TypeScript frontend for the NRC ADAMS document query application.

## Tech Stack

- **Vite** - Build tool and dev server
- **React 18** - UI framework
- **TypeScript** - Type safety
- **TanStack Query** - API state management
- **Hash-based routing** - Simple client-side navigation

## Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Start Development Server

```bash
npm run dev
```

The frontend will be available at http://localhost:5173

The dev server proxies `/api` requests to the backend at http://localhost:8000

## Features (Milestone 1)

### Query Builder Page
- Build APS search queries with:
  - Query name and search text (q parameter)
  - Main/legacy library filters (checkboxes)
  - Sort field and direction
  - Dynamic filter builder for field/operator/value combinations
  - Date field detection (hides operator input for DocumentDate and DateAddedTimestamp)
- Save queries to backend
- Run saved queries against APS API
- Navigate to results page on successful run

### Results Page
- Display query run metadata (status, timestamp, total hits, skip offset)
- Show results in a table with:
  - Checkbox selection (individual and select all)
  - Accession number, title, date, type, docket
- Ingest selected documents (placeholder for Milestone 2)

### Library Page
- Placeholder for Milestone 2 (document tree view)

### Jobs Page
- Placeholder for Milestone 4 (job monitoring and retry)

## Project Structure

```
frontend/
├── src/
│   ├── pages/            # Page components
│   │   ├── QueryBuilder.tsx
│   │   ├── Results.tsx
│   │   ├── LibraryTree.tsx (placeholder)
│   │   └── Jobs.tsx (placeholder)
│   ├── components/       # Reusable components (placeholders)
│   ├── api.ts            # Backend API client functions
│   ├── types.ts          # TypeScript type definitions
│   ├── App.tsx           # Main app with routing
│   └── main.tsx          # Entry point
├── index.html            # HTML template
├── vite.config.ts        # Vite configuration
├── package.json          # Dependencies
└── tsconfig.json         # TypeScript configuration
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally

## API Integration

The frontend uses TanStack Query for API state management and communicates with the backend via REST API:

- `POST /api/queries` - Create query
- `POST /api/queries/{id}/run?skip=N` - Run query with pagination

See `src/api.ts` for API client functions and `src/types.ts` for TypeScript interfaces.

## Styling

Uses inline styles with a simple design system:
- Color palette: Blue (#007bff, #3498db), Green (#28a745), Red (#dc3545), Gray (#6c757d)
- Responsive layout with max-width containers
- Minimal, functional UI without component libraries

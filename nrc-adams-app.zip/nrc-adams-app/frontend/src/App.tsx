import { useState, useEffect } from 'react'
import QueryBuilder from './pages/QueryBuilder'
import Results from './pages/Results'
import LibraryTree from './pages/LibraryTree'
import Jobs from './pages/Jobs'

type Page = 'query-builder' | 'results' | 'library' | 'jobs'

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('query-builder')

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1) as Page
      if (['query-builder', 'results', 'library', 'jobs'].includes(hash)) {
        setCurrentPage(hash)
      }
    }

    handleHashChange()
    window.addEventListener('hashchange', handleHashChange)
    return () => window.removeEventListener('hashchange', handleHashChange)
  }, [])

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <nav style={{
        background: '#2c3e50',
        color: 'white',
        padding: '15px 20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          gap: '30px'
        }}>
          <h2 style={{ margin: 0, fontSize: '20px' }}>NRC ADAMS Query</h2>
          
          <div style={{ display: 'flex', gap: '5px', marginLeft: 'auto' }}>
            <NavButton
              active={currentPage === 'query-builder'}
              onClick={() => {
                window.location.hash = '#query-builder'
              }}
            >
              Query Builder
            </NavButton>
            
            <NavButton
              active={currentPage === 'results'}
              onClick={() => {
                window.location.hash = '#results'
              }}
            >
              Results
            </NavButton>
            
            <NavButton
              active={currentPage === 'library'}
              onClick={() => {
                window.location.hash = '#library'
              }}
            >
              Library
            </NavButton>
            
            <NavButton
              active={currentPage === 'jobs'}
              onClick={() => {
                window.location.hash = '#jobs'
              }}
            >
              Jobs
            </NavButton>
          </div>
        </div>
      </nav>
      
      <main style={{ flex: 1, background: '#f5f5f5' }}>
        {currentPage === 'query-builder' && <QueryBuilder />}
        {currentPage === 'results' && <Results />}
        {currentPage === 'library' && <LibraryTree />}
        {currentPage === 'jobs' && <Jobs />}
      </main>
      
      <footer style={{
        background: '#34495e',
        color: 'white',
        padding: '15px 20px',
        textAlign: 'center',
        fontSize: '14px'
      }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          NRC ADAMS Query Application - Milestone 1
        </div>
      </footer>
    </div>
  )
}

function NavButton({
  active,
  onClick,
  children
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '8px 16px',
        fontSize: '14px',
        background: active ? '#3498db' : 'transparent',
        color: 'white',
        border: active ? 'none' : '1px solid rgba(255,255,255,0.3)',
        borderRadius: '4px',
        cursor: 'pointer',
        fontWeight: active ? 'bold' : 'normal',
        transition: 'all 0.2s'
      }}
      onMouseEnter={(e) => {
        if (!active) {
          e.currentTarget.style.background = 'rgba(255,255,255,0.1)'
        }
      }}
      onMouseLeave={(e) => {
        if (!active) {
          e.currentTarget.style.background = 'transparent'
        }
      }}
    >
      {children}
    </button>
  )
}

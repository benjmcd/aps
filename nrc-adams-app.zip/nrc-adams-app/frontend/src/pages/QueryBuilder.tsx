/**
 * QueryBuilder page - Build and execute APS queries
 */

import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { createQuery, runQuery } from '../api';
import { APSFilter, APSPayload } from '../types';

export default function QueryBuilder() {
  const [name, setName] = useState('');
  const [q, setQ] = useState('');
  const [mainLibFilter, setMainLibFilter] = useState(true);
  const [legacyLibFilter, setLegacyLibFilter] = useState(false);
  const [sort, setSort] = useState('');
  const [sortDirection, setSortDirection] = useState<0 | 1>(0);
  const [filters, setFilters] = useState<APSFilter[]>([]);
  const [savedQueryId, setSavedQueryId] = useState<string | null>(null);

  const createQueryMutation = useMutation({
    mutationFn: async () => {
      const payload: APSPayload = {
        q,
        mainLibFilter,
        legacyLibFilter,
        ...(sort && { sort, sortDirection }),
        ...(filters.length > 0 && { filters })
      };
      
      return createQuery(name, payload);
    },
    onSuccess: (data) => {
      setSavedQueryId(data.id);
      alert(`Query saved: ${data.name}`);
    }
  });

  const runQueryMutation = useMutation({
    mutationFn: async () => {
      if (!savedQueryId) throw new Error('No query saved');
      return runQuery(savedQueryId);
    },
    onSuccess: (data) => {
      // Store results and navigate to Results page
      sessionStorage.setItem('lastQueryRun', JSON.stringify(data));
      window.location.hash = '#results';
    }
  });

  const addFilter = () => {
    setFilters([...filters, { field: '', value: '' }]);
  };

  const updateFilter = (index: number, updates: Partial<APSFilter>) => {
    const newFilters = [...filters];
    newFilters[index] = { ...newFilters[index], ...updates };
    setFilters(newFilters);
  };

  const removeFilter = (index: number) => {
    setFilters(filters.filter((_, i) => i !== index));
  };

  const isDateField = (field: string) => {
    return field === 'DocumentDate' || field === 'DateAddedTimestamp';
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1>Query Builder</h1>
      
      <div style={{ marginBottom: '20px' }}>
        <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
          Query Name
        </label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={{
            width: '100%',
            padding: '8px',
            fontSize: '14px',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
          placeholder="e.g., Safety Reports 2024"
        />
      </div>

      <div style={{ marginBottom: '20px' }}>
        <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
          Search Query (q)
        </label>
        <input
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          style={{
            width: '100%',
            padding: '8px',
            fontSize: '14px',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
          placeholder="e.g., nuclear safety"
        />
      </div>

      <div style={{ marginBottom: '20px' }}>
        <label style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
          <input
            type="checkbox"
            checked={mainLibFilter}
            onChange={(e) => setMainLibFilter(e.target.checked)}
            style={{ marginRight: '8px' }}
          />
          Main Library Filter
        </label>
        
        <label style={{ display: 'flex', alignItems: 'center' }}>
          <input
            type="checkbox"
            checked={legacyLibFilter}
            onChange={(e) => setLegacyLibFilter(e.target.checked)}
            style={{ marginRight: '8px' }}
          />
          Legacy Library Filter
        </label>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
          Sort Field
        </label>
        <input
          type="text"
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          style={{
            width: '100%',
            padding: '8px',
            fontSize: '14px',
            border: '1px solid #ccc',
            borderRadius: '4px',
            marginBottom: '10px'
          }}
          placeholder="e.g., DocumentDate"
        />
        
        <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
          Sort Direction
        </label>
        <select
          value={sortDirection}
          onChange={(e) => setSortDirection(Number(e.target.value) as 0 | 1)}
          style={{
            padding: '8px',
            fontSize: '14px',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
        >
          <option value={0}>Ascending (0)</option>
          <option value={1}>Descending (1)</option>
        </select>
      </div>

      <div style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
          <h3>Filters</h3>
          <button
            onClick={addFilter}
            style={{
              padding: '6px 12px',
              fontSize: '14px',
              background: '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            + Add Filter
          </button>
        </div>
        
        {filters.map((filter, index) => (
          <div
            key={index}
            style={{
              display: 'grid',
              gridTemplateColumns: isDateField(filter.field) ? '1fr 2fr auto' : '1fr 1fr 1fr auto',
              gap: '10px',
              marginBottom: '10px',
              padding: '10px',
              background: '#f9f9f9',
              borderRadius: '4px'
            }}
          >
            <input
              type="text"
              value={filter.field}
              onChange={(e) => updateFilter(index, { field: e.target.value })}
              placeholder="Field (e.g., DocumentType)"
              style={{
                padding: '8px',
                fontSize: '14px',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
            
            {!isDateField(filter.field) && (
              <input
                type="text"
                value={filter.operator || ''}
                onChange={(e) => updateFilter(index, { operator: e.target.value })}
                placeholder="Operator (e.g., contains)"
                style={{
                  padding: '8px',
                  fontSize: '14px',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            )}
            
            <input
              type="text"
              value={filter.value}
              onChange={(e) => updateFilter(index, { value: e.target.value })}
              placeholder={isDateField(filter.field) ? "e.g., (DocumentDate ge '2024-01-01')" : "Value"}
              style={{
                padding: '8px',
                fontSize: '14px',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
            
            <button
              onClick={() => removeFilter(index)}
              style={{
                padding: '8px 12px',
                fontSize: '14px',
                background: '#dc3545',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: '10px' }}>
        <button
          onClick={() => createQueryMutation.mutate()}
          disabled={!name || createQueryMutation.isPending}
          style={{
            padding: '10px 20px',
            fontSize: '16px',
            background: '#28a745',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: !name || createQueryMutation.isPending ? 'not-allowed' : 'pointer',
            opacity: !name || createQueryMutation.isPending ? 0.6 : 1
          }}
        >
          {createQueryMutation.isPending ? 'Saving...' : 'Save Query'}
        </button>
        
        <button
          onClick={() => runQueryMutation.mutate()}
          disabled={!savedQueryId || runQueryMutation.isPending}
          style={{
            padding: '10px 20px',
            fontSize: '16px',
            background: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: !savedQueryId || runQueryMutation.isPending ? 'not-allowed' : 'pointer',
            opacity: !savedQueryId || runQueryMutation.isPending ? 0.6 : 1
          }}
        >
          {runQueryMutation.isPending ? 'Running...' : 'Run Query'}
        </button>
      </div>
      
      {createQueryMutation.isError && (
        <div style={{ marginTop: '20px', padding: '10px', background: '#f8d7da', color: '#721c24', borderRadius: '4px' }}>
          Error: {(createQueryMutation.error as Error).message}
        </div>
      )}
      
      {runQueryMutation.isError && (
        <div style={{ marginTop: '20px', padding: '10px', background: '#f8d7da', color: '#721c24', borderRadius: '4px' }}>
          Error: {(runQueryMutation.error as Error).message}
        </div>
      )}
    </div>
  );
}

/**
 * LibraryTree page - Browse ingested documents (Milestone 2+)
 */

export default function LibraryTree() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Library Tree</h1>
      <p style={{ color: '#666', marginTop: '10px' }}>
        This feature will be available in Milestone 2 after document ingestion is implemented.
      </p>
      <p style={{ marginTop: '10px' }}>
        The library tree will show:
      </p>
      <ul style={{ marginTop: '10px', marginLeft: '20px', color: '#666' }}>
        <li>Query → Run (timestamp) → Documents hierarchy</li>
        <li>Document metadata and download buttons</li>
        <li>Ingestion status indicators</li>
      </ul>
    </div>
  );
}

/**
 * Jobs page - Monitor and retry background jobs (Milestone 4)
 */

export default function Jobs() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Jobs</h1>
      <p style={{ color: '#666', marginTop: '10px' }}>
        This feature will be available in Milestone 4 after job processing and retry logic is implemented.
      </p>
      <p style={{ marginTop: '10px' }}>
        The jobs page will show:
      </p>
      <ul style={{ marginTop: '10px', marginLeft: '20px', color: '#666' }}>
        <li>Job status (queued, running, done, manual_review, etc.)</li>
        <li>Retry buttons for failed jobs</li>
        <li>Error messages and attempt counts</li>
        <li>Filtering by status</li>
      </ul>
    </div>
  );
}

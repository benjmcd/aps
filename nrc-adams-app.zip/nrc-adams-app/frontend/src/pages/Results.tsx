/**
 * Results page - Display query results
 */

import { useEffect, useState } from 'react';
import { QueryRunExecuteResponse, DocumentResult } from '../types';

export default function Results() {
  const [data, setData] = useState<QueryRunExecuteResponse | null>(null);
  const [selectedDocs, setSelectedDocs] = useState<Set<string>>(new Set());

  useEffect(() => {
    const stored = sessionStorage.getItem('lastQueryRun');
    if (stored) {
      setData(JSON.parse(stored));
    }
  }, []);

  if (!data) {
    return (
      <div style={{ padding: '20px' }}>
        <h1>Results</h1>
        <p>No query results available. Please run a query first.</p>
        <button
          onClick={() => window.location.hash = '#query-builder'}
          style={{
            marginTop: '10px',
            padding: '10px 20px',
            fontSize: '14px',
            background: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Go to Query Builder
        </button>
      </div>
    );
  }

  const toggleDoc = (accession: string) => {
    const newSelected = new Set(selectedDocs);
    if (newSelected.has(accession)) {
      newSelected.delete(accession);
    } else {
      newSelected.add(accession);
    }
    setSelectedDocs(newSelected);
  };

  const toggleAll = () => {
    if (selectedDocs.size === data.results.length) {
      setSelectedDocs(new Set());
    } else {
      setSelectedDocs(new Set(data.results.map(d => d.accession_number)));
    }
  };

  const handleIngest = () => {
    alert(`Ingestion will be available in Milestone 2. Selected: ${selectedDocs.size} documents`);
  };

  const meta = JSON.parse(data.query_run.aps_response_meta_json);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Query Results</h1>
      
      <div style={{ marginBottom: '20px', padding: '15px', background: '#f9f9f9', borderRadius: '4px' }}>
        <div><strong>Run ID:</strong> {data.query_run.id}</div>
        <div><strong>Status:</strong> <span style={{ 
          color: data.query_run.status === 'success' ? '#28a745' : '#dc3545',
          fontWeight: 'bold'
        }}>
          {data.query_run.status}
        </span></div>
        <div><strong>Executed:</strong> {new Date(data.query_run.executed_at).toLocaleString()}</div>
        <div><strong>Total Hits:</strong> {meta.total_hits}</div>
        <div><strong>Skip:</strong> {meta.skip}</div>
        <div><strong>Results:</strong> {data.results.length}</div>
      </div>

      <div style={{ marginBottom: '15px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <button
          onClick={toggleAll}
          style={{
            padding: '8px 16px',
            fontSize: '14px',
            background: '#6c757d',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          {selectedDocs.size === data.results.length ? 'Deselect All' : 'Select All'}
        </button>
        
        <button
          onClick={handleIngest}
          disabled={selectedDocs.size === 0}
          style={{
            padding: '8px 16px',
            fontSize: '14px',
            background: '#28a745',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: selectedDocs.size === 0 ? 'not-allowed' : 'pointer',
            opacity: selectedDocs.size === 0 ? 0.6 : 1
          }}
        >
          Ingest Selected ({selectedDocs.size})
        </button>

        <span style={{ marginLeft: 'auto', color: '#666' }}>
          {selectedDocs.size} of {data.results.length} selected
        </span>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={{
          width: '100%',
          borderCollapse: 'collapse',
          background: 'white',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
        }}>
          <thead>
            <tr style={{ background: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
              <th style={{ padding: '12px', textAlign: 'left', width: '40px' }}>
                <input
                  type="checkbox"
                  checked={selectedDocs.size === data.results.length && data.results.length > 0}
                  onChange={toggleAll}
                  style={{ cursor: 'pointer' }}
                />
              </th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Accession Number</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Title</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Date</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Type</th>
              <th style={{ padding: '12px', textAlign: 'left' }}>Docket</th>
            </tr>
          </thead>
          <tbody>
            {data.results.map((doc) => (
              <tr
                key={doc.accession_number}
                style={{
                  borderBottom: '1px solid #dee2e6',
                  background: selectedDocs.has(doc.accession_number) ? '#e7f3ff' : 'white'
                }}
              >
                <td style={{ padding: '12px' }}>
                  <input
                    type="checkbox"
                    checked={selectedDocs.has(doc.accession_number)}
                    onChange={() => toggleDoc(doc.accession_number)}
                    style={{ cursor: 'pointer' }}
                  />
                </td>
                <td style={{ padding: '12px', fontFamily: 'monospace', fontSize: '13px' }}>
                  {doc.accession_number}
                </td>
                <td style={{ padding: '12px' }}>
                  {doc.title || <em style={{ color: '#999' }}>No title</em>}
                </td>
                <td style={{ padding: '12px' }}>
                  {doc.document_date || <em style={{ color: '#999' }}>—</em>}
                </td>
                <td style={{ padding: '12px', fontSize: '13px' }}>
                  {doc.document_type?.join(', ') || <em style={{ color: '#999' }}>—</em>}
                </td>
                <td style={{ padding: '12px', fontSize: '13px' }}>
                  {doc.docket_number?.join(', ') || <em style={{ color: '#999' }}>—</em>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data.results.length === 0 && (
        <div style={{
          padding: '40px',
          textAlign: 'center',
          color: '#666',
          background: 'white',
          borderRadius: '4px'
        }}>
          No results found for this query.
        </div>
      )}
    </div>
  );
}

/**
 * API client for backend communication
 */

import { Query, QueryRunExecuteResponse, APSPayload } from './types';

const API_BASE = '/api';

export async function createQuery(name: string, aps_payload: APSPayload): Promise<Query> {
  const response = await fetch(`${API_BASE}/queries`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, aps_payload })
  });
  
  if (!response.ok) {
    throw new Error(`Failed to create query: ${response.statusText}`);
  }
  
  return response.json();
}

export async function runQuery(
  queryId: string,
  skip: number = 0,
  aps_payload_override?: APSPayload
): Promise<QueryRunExecuteResponse> {
  const url = new URL(`${API_BASE}/queries/${queryId}/run`, window.location.origin);
  url.searchParams.set('skip', skip.toString());
  
  const body = aps_payload_override ? { aps_payload_override } : null;
  
  const response = await fetch(url.toString(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    ...(body && { body: JSON.stringify(body) })
  });
  
  if (!response.ok) {
    throw new Error(`Failed to run query: ${response.statusText}`);
  }
  
  return response.json();
}

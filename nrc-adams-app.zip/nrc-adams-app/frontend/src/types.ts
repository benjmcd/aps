/**
 * TypeScript type definitions for NRC ADAMS API
 */

export interface Query {
  id: string;
  name: string;
  aps_payload_json: string;
  created_at: string;
}

export interface QueryRun {
  id: string;
  query_id: string;
  executed_at: string;
  aps_response_meta_json: string;
  status: 'success' | 'error';
  error_json: string | null;
}

export interface DocumentResult {
  accession_number: string;
  title?: string;
  document_date?: string;
  document_type?: string[];
  docket_number?: string[];
  url?: string;
}

export interface QueryRunExecuteResponse {
  query_run: QueryRun;
  results: DocumentResult[];
}

export interface APSPayload {
  q?: string;
  filters?: APSFilter[];
  anyFilters?: APSFilter[];
  legacyLibFilter?: boolean;
  mainLibFilter?: boolean;
  sort?: string;
  sortDirection?: 0 | 1;
  skip?: number;
}

export interface APSFilter {
  field: string;
  operator?: string;
  value: string;
}

/**
 * StatusBadge component for displaying job/query status (Milestone 2+)
 */

export default function StatusBadge() {
  return null;
}

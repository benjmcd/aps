/**
 * Table component for data display (Milestone 2+)
 */

export default function Table() {
  return null;
}

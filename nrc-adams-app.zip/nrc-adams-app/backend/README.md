# NRC ADAMS Query Backend

Backend API for querying and storing NRC ADAMS Public Search documents.

## Tech Stack

- **Python 3.12**
- **FastAPI** - Web framework
- **SQLAlchemy 2.x** - ORM and database management
- **Alembic** - Database migrations
- **httpx** - HTTP client for APS API
- **SQLite** - Default database (configurable)

## Setup

### 1. Install Dependencies

```bash
pip install -e ".[dev]"
```

### 2. Configure Environment

Copy `.env.example` to `.env` and configure:

```bash
cp ../.env.example .env
```

Required environment variables:
- `APS_SUBSCRIPTION_KEY` - NRC APS API subscription key
- `DATABASE_URL` - Database connection string (default: `sqlite:///./data/app.db`)
- `BLOB_ROOT` - Directory for storing PDF files (default: `./data/blobs`)
- `CORS_ORIGINS` - Allowed CORS origins (default: `http://localhost:5173`)

### 3. Run Database Migrations

```bash
alembic upgrade head
```

### 4. Start Development Server

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at http://localhost:8000

API documentation: http://localhost:8000/docs

## Testing

Run tests with pytest:

```bash
pytest
```

Tests use mocked HTTP responses and an in-memory SQLite database. No live NRC APS connectivity is required.

## API Endpoints (Milestone 1)

### Queries

- `POST /api/queries` - Create a new saved query
- `POST /api/queries/{query_id}/run` - Execute a query and persist results

## Database Schema

See `alembic/versions/0001_init.py` for the complete schema definition.

Key tables:
- `queries` - Saved query definitions
- `query_runs` - Execution records of queries
- `documents` - Document metadata and file information
- `query_run_documents` - Junction table linking runs to documents
- `document_text` - Partitioned text chunks (Milestone 3)
- `jobs` - Background job queue (Milestone 2+)

## Development

### Project Structure

```
backend/
├── app/
│   ├── api/              # FastAPI route handlers
│   ├── services/         # Business logic
│   ├── tests/            # Test suite
│   ├── config.py         # Configuration management
│   ├── db.py             # Database setup
│   ├── models.py         # SQLAlchemy models
│   ├── schemas.py        # Pydantic request/response models
│   ├── aps_client.py     # NRC APS HTTP client
│   └── main.py           # FastAPI application
├── alembic/              # Database migrations
└── pyproject.toml        # Dependencies and metadata
```

### Running Migrations

Create a new migration:
```bash
alembic revision -m "description"
```

Apply migrations:
```bash
alembic upgrade head
```

Rollback:
```bash
alembic downgrade -1
```

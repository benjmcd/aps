"""Test query API routes with mocked APS responses."""
import pytest
import respx
import httpx
from ..models import Query, QueryRun, QueryRunDocument, Document


@respx.mock
@pytest.mark.asyncio
async def test_create_query(client):
    """Test creating a new query."""
    payload = {
        "q": "nuclear safety",
        "filters": [{"field": "DocumentType", "value": "Report"}],
        "mainLibFilter": True,
        "skip": 0
    }
    
    response = client.post("/api/queries", json={
        "name": "Test Query",
        "aps_payload": payload
    })
    
    assert response.status_code == 200
    data = response.json()
    
    assert data["name"] == "Test Query"
    assert "id" in data
    assert "created_at" in data
    assert "aps_payload_json" in data
    
    # Verify payload is canonicalized
    import json
    parsed = json.loads(data["aps_payload_json"])
    assert parsed["q"] == "nuclear safety"


@respx.mock
@pytest.mark.asyncio
async def test_run_query_success(client, db_session, aps_search_response):
    """Test running a query with mocked APS response."""
    # First create a query
    payload = {
        "q": "nuclear safety",
        "mainLibFilter": True,
        "skip": 0
    }
    
    create_response = client.post("/api/queries", json={
        "name": "Test Query",
        "aps_payload": payload
    })
    query_id = create_response.json()["id"]
    
    # Mock the APS search endpoint
    respx.post("https://adams-api.nrc.gov/aps/api/search").mock(
        return_value=httpx.Response(200, json=aps_search_response)
    )
    
    # Run the query
    run_response = client.post(f"/api/queries/{query_id}/run")
    
    assert run_response.status_code == 200
    data = run_response.json()
    
    # Check query_run
    assert data["query_run"]["status"] == "success"
    assert data["query_run"]["query_id"] == query_id
    
    # Check results
    assert len(data["results"]) == 2
    assert data["results"][0]["accession_number"] == "ML24001A001"
    assert data["results"][0]["title"] == "Sample Document 1"
    
    # Verify database state
    query_run = db_session.query(QueryRun).filter(
        QueryRun.id == data["query_run"]["id"]
    ).first()
    
    assert query_run is not None
    assert query_run.status == "success"
    
    # Verify query_run_documents created with 'seen' disposition
    qrds = db_session.query(QueryRunDocument).filter(
        QueryRunDocument.query_run_id == query_run.id
    ).all()
    
    assert len(qrds) == 2
    for qrd in qrds:
        assert qrd.disposition == "seen"
    
    # Verify documents created
    docs = db_session.query(Document).all()
    assert len(docs) == 2
    
    doc1 = db_session.query(Document).filter(
        Document.accession_number == "ML24001A001"
    ).first()
    
    assert doc1.title == "Sample Document 1"
    assert doc1.document_date == "2024-01-15"
    assert doc1.url is not None


@respx.mock
@pytest.mark.asyncio
async def test_run_query_with_skip_pagination(client, db_session, aps_search_response):
    """Test running a query with skip parameter for pagination."""
    # Create a query
    payload = {
        "q": "reactor",
        "mainLibFilter": True
    }
    
    create_response = client.post("/api/queries", json={
        "name": "Paginated Query",
        "aps_payload": payload
    })
    query_id = create_response.json()["id"]
    
    # Mock the APS search endpoint
    mock_route = respx.post("https://adams-api.nrc.gov/aps/api/search").mock(
        return_value=httpx.Response(200, json=aps_search_response)
    )
    
    # Run the query with skip=10
    run_response = client.post(f"/api/queries/{query_id}/run?skip=10")
    
    assert run_response.status_code == 200
    
    # Verify the request sent to APS included skip=10
    assert mock_route.called
    request = mock_route.calls.last.request
    request_payload = request.content.decode('utf-8')
    import json
    parsed_request = json.loads(request_payload)
    assert parsed_request["skip"] == 10
    
    # Verify response_meta includes skip
    data = run_response.json()
    import json
    meta = json.loads(data["query_run"]["aps_response_meta_json"])
    assert meta["skip"] == 10


@respx.mock
@pytest.mark.asyncio
async def test_run_query_idempotent_documents(client, db_session, aps_search_response):
    """Test that running the same query multiple times doesn't duplicate documents."""
    # Create a query
    payload = {
        "q": "test",
        "mainLibFilter": True
    }
    
    create_response = client.post("/api/queries", json={
        "name": "Idempotent Test",
        "aps_payload": payload
    })
    query_id = create_response.json()["id"]
    
    # Mock the APS search endpoint
    respx.post("https://adams-api.nrc.gov/aps/api/search").mock(
        return_value=httpx.Response(200, json=aps_search_response)
    )
    
    # Run query first time
    client.post(f"/api/queries/{query_id}/run")
    
    # Count documents
    docs_count_1 = db_session.query(Document).count()
    
    # Run query second time
    client.post(f"/api/queries/{query_id}/run")
    
    # Count documents again
    docs_count_2 = db_session.query(Document).count()
    
    # Should have same number of documents (upsert, not duplicate)
    assert docs_count_1 == docs_count_2
    assert docs_count_1 == 2


@respx.mock
@pytest.mark.asyncio
async def test_run_nonexistent_query(client):
    """Test running a query that doesn't exist."""
    response = client.post("/api/queries/nonexistent-id/run")
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()

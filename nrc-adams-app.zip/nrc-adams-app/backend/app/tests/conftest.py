"""Pytest configuration and fixtures."""
import pytest
import json
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from ..db import Base, get_db
from ..main import app
from ..config import Config


# Test database URL
TEST_DATABASE_URL = "sqlite:///:memory:"


@pytest.fixture(scope="function")
def db_engine():
    """Create a test database engine."""
    engine = create_engine(
        TEST_DATABASE_URL,
        connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(bind=engine)
    yield engine
    Base.metadata.drop_all(bind=engine)
    engine.dispose()


@pytest.fixture(scope="function")
def db_session(db_engine):
    """Create a test database session."""
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=db_engine)
    session = TestingSessionLocal()
    yield session
    session.close()


@pytest.fixture(scope="function")
def client(db_session):
    """Create a test client with database override."""
    def override_get_db():
        try:
            yield db_session
        finally:
            pass
    
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def aps_search_response():
    """Load APS search response fixture."""
    fixtures_dir = Path(__file__).parent / "fixtures"
    with open(fixtures_dir / "aps_search_response.json") as f:
        return json.load(f)


@pytest.fixture
def aps_getdoc_response():
    """Load APS get document response fixture."""
    fixtures_dir = Path(__file__).parent / "fixtures"
    with open(fixtures_dir / "aps_getdoc_response.json") as f:
        return json.load(f)


@pytest.fixture
def sample_pdf_path():
    """Path to sample PDF fixture."""
    return Path(__file__).parent / "fixtures" / "sample.pdf"

"""Test ingestion idempotency (Milestone 2)."""
import pytest

# This test will be implemented in Milestone 2
# It will verify that ingesting the same document twice does not
# duplicate files or re-download unless force=True


@pytest.mark.skip(reason="Milestone 2: Ingestion not yet implemented")
def test_ingest_idempotent():
    """Test that re-ingesting a document is idempotent unless force=True."""
    pass

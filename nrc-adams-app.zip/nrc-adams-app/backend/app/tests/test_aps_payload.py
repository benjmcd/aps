"""Test APS payload canonicalization."""
from ..services.query_service import canonicalize_payload


def test_payload_canonicalization_stable():
    """Test that payload canonicalization produces stable output."""
    payload1 = {
        "q": "reactor",
        "filters": [{"field": "DocumentType", "value": "Letter"}],
        "mainLibFilter": True,
        "skip": 0
    }
    
    # Same payload with different key order
    payload2 = {
        "skip": 0,
        "mainLibFilter": True,
        "q": "reactor",
        "filters": [{"field": "DocumentType", "value": "Letter"}]
    }
    
    canonical1 = canonicalize_payload(payload1)
    canonical2 = canonicalize_payload(payload2)
    
    # Should produce identical canonical strings
    assert canonical1 == canonical2
    
    # Should be valid JSON
    import json
    parsed = json.loads(canonical1)
    assert parsed["q"] == "reactor"


def test_payload_canonicalization_sorted_keys():
    """Test that keys are sorted alphabetically."""
    payload = {
        "z": 1,
        "a": 2,
        "m": 3
    }
    
    canonical = canonicalize_payload(payload)
    
    # Keys should be sorted: a, m, z
    assert canonical == '{"a":2,"m":3,"z":1}'


def test_payload_canonicalization_no_whitespace():
    """Test that canonicalization has no unnecessary whitespace."""
    payload = {
        "q": "test query",
        "skip": 0
    }
    
    canonical = canonicalize_payload(payload)
    
    # Should use compact JSON format
    assert ' ' not in canonical.replace("test query", "testquery")
    assert '\n' not in canonical

"""Service for text chunking and storage (Milestone 3)."""
# To be implemented in Milestone 3

CHUNK_SIZE = 4000
CHUNK_OVERLAP = 200

"""Service for managing queries and query runs."""
import json
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, List, Tuple
from sqlalchemy.orm import Session

from ..models import Query, QueryRun, Document, QueryRunDocument
from ..aps_client import aps_client


def canonicalize_payload(payload: Dict[str, Any]) -> str:
    """
    Convert APS payload to canonical JSON string.
    Keys are sorted alphabetically, no secrets included.
    """
    return json.dumps(payload, sort_keys=True, separators=(',', ':'))


def create_query(db: Session, name: str, aps_payload: Dict[str, Any]) -> Query:
    """
    Create a new saved query.
    
    Args:
        db: Database session
        name: Human-readable query name
        aps_payload: APS search payload object
    
    Returns:
        Created Query object
    """
    query_id = str(uuid.uuid4())
    canonical_payload = canonicalize_payload(aps_payload)
    
    query = Query(
        id=query_id,
        name=name,
        aps_payload_json=canonical_payload,
        created_at=datetime.now(timezone.utc).isoformat()
    )
    
    db.add(query)
    db.commit()
    db.refresh(query)
    
    return query


async def run_query(
    db: Session,
    query: Query,
    aps_payload_override: Dict[str, Any] = None
) -> Tuple[QueryRun, List[Dict[str, Any]]]:
    """
    Execute a query against the APS API and persist results.
    
    Args:
        db: Database session
        query: The Query object to run
        aps_payload_override: Optional override payload for this run
    
    Returns:
        Tuple of (QueryRun object, list of document result dicts)
    """
    # Determine which payload to use
    if aps_payload_override:
        payload = aps_payload_override
    else:
        payload = json.loads(query.aps_payload_json)
    
    # Execute APS search
    try:
        aps_response = await aps_client.search(payload)
        status = "success"
        error_json = None
    except Exception as e:
        aps_response = {}
        status = "error"
        error_json = json.dumps({"error": str(e)})
    
    # Create query run record
    run_id = str(uuid.uuid4())
    
    # Store metadata: total hits and skip used
    response_meta = {
        "total_hits": aps_response.get("total", 0),
        "skip": payload.get("skip", 0)
    }
    
    query_run = QueryRun(
        id=run_id,
        query_id=query.id,
        executed_at=datetime.now(timezone.utc).isoformat(),
        aps_response_meta_json=json.dumps(response_meta),
        status=status,
        error_json=error_json
    )
    
    db.add(query_run)
    
    # Process results and create document records
    results = []
    documents_data = aps_response.get("results", [])
    
    for doc_data in documents_data:
        accession_number = doc_data.get("AccessionNumber")
        if not accession_number:
            continue
        
        # Upsert document record
        document = db.query(Document).filter(
            Document.accession_number == accession_number
        ).first()
        
        if not document:
            document = Document(accession_number=accession_number)
            db.add(document)
        
        # Update metadata if provided
        if doc_data.get("DocumentTitle"):
            document.title = doc_data["DocumentTitle"]
        if doc_data.get("DocumentDate"):
            document.document_date = doc_data["DocumentDate"]
        if doc_data.get("DocumentType"):
            doc_types = doc_data["DocumentType"]
            if isinstance(doc_types, list):
                document.document_type_json = json.dumps(doc_types)
        if doc_data.get("DocketNumber"):
            docket_nums = doc_data["DocketNumber"]
            if isinstance(docket_nums, list):
                document.docket_number_json = json.dumps(docket_nums)
        if doc_data.get("Url"):
            document.url = doc_data["Url"]
        
        # Create query_run_document link with 'seen' disposition
        qrd = QueryRunDocument(
            query_run_id=run_id,
            accession_number=accession_number,
            disposition="seen",
            notes=None
        )
        db.add(qrd)
        
        # Build result dict
        result = {
            "accession_number": accession_number,
            "title": document.title,
            "document_date": document.document_date,
            "document_type": json.loads(document.document_type_json) if document.document_type_json else None,
            "docket_number": json.loads(document.docket_number_json) if document.docket_number_json else None,
            "url": document.url
        }
        results.append(result)
    
    db.commit()
    db.refresh(query_run)
    
    return query_run, results

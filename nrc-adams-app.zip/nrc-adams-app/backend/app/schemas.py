"""Pydantic models for API request/response validation."""
from typing import Optional, List, Dict, Any
from pydantic import BaseModel


# Query schemas
class QueryCreate(BaseModel):
    name: str
    aps_payload: Dict[str, Any]


class QueryResponse(BaseModel):
    id: str
    name: str
    aps_payload_json: str
    created_at: str
    
    class Config:
        from_attributes = True


# Query Run schemas
class QueryRunOverride(BaseModel):
    aps_payload_override: Optional[Dict[str, Any]] = None


class DocumentResult(BaseModel):
    accession_number: str
    title: Optional[str] = None
    document_date: Optional[str] = None
    document_type: Optional[List[str]] = None
    docket_number: Optional[List[str]] = None
    url: Optional[str] = None


class QueryRunResponse(BaseModel):
    id: str
    query_id: str
    executed_at: str
    aps_response_meta_json: str
    status: str
    error_json: Optional[str] = None
    
    class Config:
        from_attributes = True


class QueryRunExecuteResponse(BaseModel):
    query_run: QueryRunResponse
    results: List[DocumentResult]


# Ingest schemas
class IngestRequest(BaseModel):
    accession_numbers: List[str]
    force: bool = False


class JobResponse(BaseModel):
    id: str
    kind: str
    accession_number: str
    query_run_id: Optional[str] = None
    status: str
    attempt: int
    max_attempts: int
    last_error_json: Optional[str] = None
    created_at: str
    updated_at: str
    
    class Config:
        from_attributes = True


# Library tree schemas
class LibraryDocumentResponse(BaseModel):
    accession_number: str
    title: Optional[str] = None
    document_date: Optional[str] = None
    disposition: str
    ingested_at: Optional[str] = None
    stored_path: Optional[str] = None


class LibraryRunResponse(BaseModel):
    query_run: QueryRunResponse
    documents: List[LibraryDocumentResponse]


class LibraryTreeResponse(BaseModel):
    query: QueryResponse
    runs: List[LibraryRunResponse]

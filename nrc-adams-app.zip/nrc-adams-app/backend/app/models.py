"""SQLAlchemy ORM models matching the database schema exactly."""
from sqlalchemy import Column, Text, Integer, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import relationship

from .db import Base


class Query(Base):
    """Stores saved queries with their APS payload."""
    __tablename__ = "queries"
    
    id = Column(Text, primary_key=True)
    name = Column(Text, nullable=False)
    aps_payload_json = Column(Text, nullable=False)
    created_at = Column(Text, nullable=False)
    
    # Relationships
    runs = relationship("QueryRun", back_populates="query")


class QueryRun(Base):
    """Stores execution records of queries."""
    __tablename__ = "query_runs"
    
    id = Column(Text, primary_key=True)
    query_id = Column(Text, ForeignKey("queries.id"), nullable=False)
    executed_at = Column(Text, nullable=False)
    aps_response_meta_json = Column(Text, nullable=False)
    status = Column(Text, nullable=False)
    error_json = Column(Text, nullable=True)
    
    __table_args__ = (
        CheckConstraint("status IN ('success', 'error')", name="check_status"),
    )
    
    # Relationships
    query = relationship("Query", back_populates="runs")
    documents = relationship("QueryRunDocument", back_populates="query_run")


class Document(Base):
    """Stores document metadata and file information."""
    __tablename__ = "documents"
    
    accession_number = Column(Text, primary_key=True)
    title = Column(Text, nullable=True)
    document_date = Column(Text, nullable=True)
    document_type_json = Column(Text, nullable=True)
    docket_number_json = Column(Text, nullable=True)
    url = Column(Text, nullable=True)
    sha256 = Column(Text, nullable=True)
    byte_size = Column(Integer, nullable=True)
    stored_path = Column(Text, nullable=True)
    ingested_at = Column(Text, nullable=True)
    
    # Relationships
    query_runs = relationship("QueryRunDocument", back_populates="document")
    text_chunks = relationship("DocumentText", back_populates="document")


class QueryRunDocument(Base):
    """Junction table linking query runs to documents with disposition."""
    __tablename__ = "query_run_documents"
    
    query_run_id = Column(Text, ForeignKey("query_runs.id"), primary_key=True)
    accession_number = Column(Text, ForeignKey("documents.accession_number"), primary_key=True)
    disposition = Column(Text, nullable=False)
    notes = Column(Text, nullable=True)
    
    __table_args__ = (
        CheckConstraint("disposition IN ('seen', 'ingested', 'skipped', 'error')", name="check_disposition"),
    )
    
    # Relationships
    query_run = relationship("QueryRun", back_populates="documents")
    document = relationship("Document", back_populates="query_runs")


class DocumentText(Base):
    """Stores partitioned text chunks from documents."""
    __tablename__ = "document_text"
    
    id = Column(Text, primary_key=True)
    accession_number = Column(Text, ForeignKey("documents.accession_number"), nullable=False)
    source = Column(Text, nullable=False)
    chunk_index = Column(Integer, nullable=False)
    char_start = Column(Integer, nullable=False)
    char_end = Column(Integer, nullable=False)
    text = Column(Text, nullable=False)
    
    __table_args__ = (
        CheckConstraint("source IN ('aps_indexed_content', 'pdf_extract')", name="check_source"),
        UniqueConstraint("accession_number", "source", "chunk_index", name="unique_chunk"),
    )
    
    # Relationships
    document = relationship("Document", back_populates="text_chunks")


class Job(Base):
    """Stores background job status and retries."""
    __tablename__ = "jobs"
    
    id = Column(Text, primary_key=True)
    kind = Column(Text, nullable=False)
    accession_number = Column(Text, nullable=False)
    query_run_id = Column(Text, nullable=True)
    status = Column(Text, nullable=False)
    attempt = Column(Integer, nullable=False)
    max_attempts = Column(Integer, nullable=False, default=3)
    last_error_json = Column(Text, nullable=True)
    created_at = Column(Text, nullable=False)
    updated_at = Column(Text, nullable=False)
    
    __table_args__ = (
        CheckConstraint("kind IN ('ingest_document')", name="check_kind"),
        CheckConstraint("status IN ('queued', 'running', 'retrying', 'failed', 'manual_review', 'done')", name="check_job_status"),
    )

"""Application configuration loaded from environment variables."""
import os
from pathlib import Path
from typing import List


class Config:
    """Application configuration with defaults and validation."""
    
    def __init__(self):
        self.APS_SUBSCRIPTION_KEY = os.getenv("APS_SUBSCRIPTION_KEY", "")
        self.DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/app.db")
        self.BLOB_ROOT = Path(os.getenv("BLOB_ROOT", "./data/blobs"))
        self.CORS_ORIGINS = [
            origin.strip() 
            for origin in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
        ]
        
        # Ensure blob root directory exists
        self.BLOB_ROOT.mkdir(parents=True, exist_ok=True)
    
    def validate(self):
        """Validate configuration (can be extended for production checks)."""
        # In production, we'd want to ensure APS_SUBSCRIPTION_KEY is set
        # For now, allow empty for testing
        pass


config = Config()
config.validate()

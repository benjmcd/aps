"""HTTP client for NRC ADAMS Public Search (APS) API."""
import httpx
from typing import Dict, Any

from .config import config


class APSClient:
    """Client for interacting with the NRC APS API."""
    
    BASE_URL = "https://adams-api.nrc.gov/aps/api"
    
    def __init__(self, subscription_key: str = None):
        self.subscription_key = subscription_key or config.APS_SUBSCRIPTION_KEY
        self.headers = {
            "Ocp-Apim-Subscription-Key": self.subscription_key
        }
    
    async def search(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a search query against the APS API.
        
        Args:
            payload: Search request body including q, filters, sort, etc.
        
        Returns:
            JSON response from APS API
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.BASE_URL}/search",
                json=payload,
                headers=self.headers,
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()
    
    async def get_doc(self, accession_number: str) -> Dict[str, Any]:
        """
        Get document metadata and indexed content by accession number.
        
        Args:
            accession_number: The document's accession number
        
        Returns:
            JSON response with document details and indexed content
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.BASE_URL}/search/{accession_number}",
                headers=self.headers,
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()


# Singleton instance
aps_client = APSClient()

"""NRC ADAMS Query Application - Backend."""

"""API routes for jobs (Milestone 4)."""
from fastapi import APIRouter

router = APIRouter(prefix="/api/jobs", tags=["jobs"])

# Routes to be implemented in Milestone 4

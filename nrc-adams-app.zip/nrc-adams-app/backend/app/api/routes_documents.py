"""API routes for documents and downloads (Milestone 2+)."""
from fastapi import APIRouter

router = APIRouter(prefix="/api", tags=["documents"])

# Routes to be implemented in Milestone 2

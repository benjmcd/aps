"""API routes for queries and query execution."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Query
from ..schemas import QueryCreate, QueryResponse, QueryRunOverride, QueryRunExecuteResponse
from ..services.query_service import create_query, run_query


router = APIRouter(prefix="/api/queries", tags=["queries"])


@router.post("", response_model=QueryResponse)
async def create_query_endpoint(
    request: QueryCreate,
    db: Session = Depends(get_db)
):
    """
    Create a new saved query.
    
    Args:
        request: Query creation request with name and APS payload
        db: Database session
    
    Returns:
        Created query object
    """
    query = create_query(db, request.name, request.aps_payload)
    return query


@router.post("/{query_id}/run", response_model=QueryRunExecuteResponse)
async def run_query_endpoint(
    query_id: str,
    request: QueryRunOverride = None,
    skip: int = 0,
    db: Session = Depends(get_db)
):
    """
    Execute a query against the APS API.
    
    Args:
        query_id: ID of the query to run
        request: Optional payload override
        skip: Pagination offset (injected into payload)
        db: Database session
    
    Returns:
        Query run record and document results
    """
    # Fetch the query
    query = db.query(Query).filter(Query.id == query_id).first()
    if not query:
        raise HTTPException(status_code=404, detail="Query not found")
    
    # Determine payload
    import json
    if request and request.aps_payload_override:
        payload = request.aps_payload_override
    else:
        payload = json.loads(query.aps_payload_json)
    
    # Inject skip parameter
    payload["skip"] = skip
    
    # Run the query
    query_run, results = await run_query(db, query, payload)
    
    return QueryRunExecuteResponse(
        query_run=query_run,
        results=results
    )

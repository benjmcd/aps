"""API routes for query runs (Milestone 2+)."""
from fastapi import APIRouter

router = APIRouter(prefix="/api/query-runs", tags=["query-runs"])

# Routes to be implemented in Milestone 2

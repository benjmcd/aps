"""FastAPI application entry point."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import config
from .api import routes_queries, routes_runs, routes_documents, routes_jobs


# Create FastAPI app
app = FastAPI(
    title="NRC ADAMS Query API",
    description="Local-first application for querying and storing NRC ADAMS documents",
    version="0.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(routes_queries.router)
app.include_router(routes_runs.router)
app.include_router(routes_documents.router)
app.include_router(routes_jobs.router)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {"status": "ok", "message": "NRC ADAMS Query API"}


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}

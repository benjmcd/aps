"""Initial schema

Revision ID: 0001_init
Revises: 
Create Date: 2025-02-08

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '0001_init'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create queries table
    op.create_table(
        'queries',
        sa.Column('id', sa.Text(), nullable=False),
        sa.Column('name', sa.Text(), nullable=False),
        sa.Column('aps_payload_json', sa.Text(), nullable=False),
        sa.Column('created_at', sa.Text(), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Create query_runs table
    op.create_table(
        'query_runs',
        sa.Column('id', sa.Text(), nullable=False),
        sa.Column('query_id', sa.Text(), nullable=False),
        sa.Column('executed_at', sa.Text(), nullable=False),
        sa.Column('aps_response_meta_json', sa.Text(), nullable=False),
        sa.Column('status', sa.Text(), nullable=False),
        sa.Column('error_json', sa.Text(), nullable=True),
        sa.CheckConstraint("status IN ('success', 'error')", name='check_status'),
        sa.ForeignKeyConstraint(['query_id'], ['queries.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Create documents table
    op.create_table(
        'documents',
        sa.Column('accession_number', sa.Text(), nullable=False),
        sa.Column('title', sa.Text(), nullable=True),
        sa.Column('document_date', sa.Text(), nullable=True),
        sa.Column('document_type_json', sa.Text(), nullable=True),
        sa.Column('docket_number_json', sa.Text(), nullable=True),
        sa.Column('url', sa.Text(), nullable=True),
        sa.Column('sha256', sa.Text(), nullable=True),
        sa.Column('byte_size', sa.Integer(), nullable=True),
        sa.Column('stored_path', sa.Text(), nullable=True),
        sa.Column('ingested_at', sa.Text(), nullable=True),
        sa.PrimaryKeyConstraint('accession_number')
    )
    
    # Create query_run_documents table
    op.create_table(
        'query_run_documents',
        sa.Column('query_run_id', sa.Text(), nullable=False),
        sa.Column('accession_number', sa.Text(), nullable=False),
        sa.Column('disposition', sa.Text(), nullable=False),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.CheckConstraint("disposition IN ('seen', 'ingested', 'skipped', 'error')", name='check_disposition'),
        sa.ForeignKeyConstraint(['accession_number'], ['documents.accession_number'], ),
        sa.ForeignKeyConstraint(['query_run_id'], ['query_runs.id'], ),
        sa.PrimaryKeyConstraint('query_run_id', 'accession_number')
    )
    
    # Create document_text table
    op.create_table(
        'document_text',
        sa.Column('id', sa.Text(), nullable=False),
        sa.Column('accession_number', sa.Text(), nullable=False),
        sa.Column('source', sa.Text(), nullable=False),
        sa.Column('chunk_index', sa.Integer(), nullable=False),
        sa.Column('char_start', sa.Integer(), nullable=False),
        sa.Column('char_end', sa.Integer(), nullable=False),
        sa.Column('text', sa.Text(), nullable=False),
        sa.CheckConstraint("source IN ('aps_indexed_content', 'pdf_extract')", name='check_source'),
        sa.ForeignKeyConstraint(['accession_number'], ['documents.accession_number'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('accession_number', 'source', 'chunk_index', name='unique_chunk')
    )
    
    # Create jobs table
    op.create_table(
        'jobs',
        sa.Column('id', sa.Text(), nullable=False),
        sa.Column('kind', sa.Text(), nullable=False),
        sa.Column('accession_number', sa.Text(), nullable=False),
        sa.Column('query_run_id', sa.Text(), nullable=True),
        sa.Column('status', sa.Text(), nullable=False),
        sa.Column('attempt', sa.Integer(), nullable=False),
        sa.Column('max_attempts', sa.Integer(), nullable=False, server_default='3'),
        sa.Column('last_error_json', sa.Text(), nullable=True),
        sa.Column('created_at', sa.Text(), nullable=False),
        sa.Column('updated_at', sa.Text(), nullable=False),
        sa.CheckConstraint("kind IN ('ingest_document')", name='check_kind'),
        sa.CheckConstraint("status IN ('queued', 'running', 'retrying', 'failed', 'manual_review', 'done')", name='check_job_status'),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade() -> None:
    op.drop_table('jobs')
    op.drop_table('document_text')
    op.drop_table('query_run_documents')
    op.drop_table('documents')
    op.drop_table('query_runs')
    op.drop_table('queries')
